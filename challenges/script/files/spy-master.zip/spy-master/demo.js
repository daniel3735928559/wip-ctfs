var app = app || angular.module('app', []);

app.controller("DemoController", ['$scope',function($scope){
    $scope.prog = "x = 27";
    $scope.pycontrol = {};
}]);

